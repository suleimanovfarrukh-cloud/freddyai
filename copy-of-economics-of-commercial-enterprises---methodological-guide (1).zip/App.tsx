import React, { useState, useMemo, useEffect } from 'react';
import { 
  BookOpen, 
  Menu, 
  X, 
  ChevronRight, 
  Target, 
  FileText, 
  Users, 
  HelpCircle, 
  Briefcase, 
  AlertTriangle,
  Search,
  Download,
  Printer,
  Home,
  CheckCircle2,
  Info,
  LayoutGrid,
  ArrowRight,
  TrendingUp,
  Award,
  Layers,
  ChevronDown,
  Globe,
  GraduationCap
} from 'lucide-react';
import { topics } from './data';
import { Topic, PracticalTask, CaseStudy, ProblemSituation } from './types';

// --- UI Components ---

const SectionHeader: React.FC<{ icon: React.ReactNode; title: string }> = ({ icon, title }) => (
  <div className="flex items-center gap-4 mb-8 mt-16 pb-4 border-b border-slate-200">
    <div className="text-blue-600 p-2.5 bg-blue-50 rounded-xl shadow-sm">{icon}</div>
    <h2 className="text-2xl font-black text-slate-800 uppercase tracking-tight">{title}</h2>
  </div>
);

const Badge: React.FC<{ children: React.ReactNode; color?: 'blue' | 'green' | 'amber' | 'rose' | 'slate'; className?: string }> = ({ children, color = "blue", className = "" }) => {
  const colors = {
    blue: "bg-blue-50 text-blue-700 border-blue-100",
    green: "bg-green-50 text-green-700 border-green-100",
    amber: "bg-amber-50 text-amber-700 border-amber-100",
    rose: "bg-rose-50 text-rose-700 border-rose-100",
    slate: "bg-slate-50 text-slate-700 border-slate-200",
  };
  return (
    <span className={`px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-widest border ${colors[color]} ${className}`}>
      {children}
    </span>
  );
};

const App: React.FC = () => {
  const [selectedTopicId, setSelectedTopicId] = useState<number | null>(null);
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 50);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const currentTopic = useMemo(() => 
    topics.find(t => t.id === selectedTopicId) || null
  , [selectedTopicId]);

  const filteredTopics = useMemo(() => 
    topics.filter(t => 
      t.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      t.summary.toLowerCase().includes(searchQuery.toLowerCase())
    )
  , [searchQuery]);

  const handlePrint = () => window.print();

  return (
    <div className="min-h-screen bg-white text-slate-900 selection:bg-blue-600 selection:text-white font-['Inter']">
      
      {/* --- Modern Navigation --- */}
      <nav className={`fixed top-0 left-0 right-0 z-[100] transition-all duration-300 no-print ${
        scrolled ? 'bg-white/80 backdrop-blur-md shadow-lg py-3' : 'bg-transparent py-6'
      }`}>
        <div className="max-w-7xl mx-auto px-6 flex justify-between items-center">
          <div 
            className="flex items-center gap-3 cursor-pointer group"
            onClick={() => setSelectedTopicId(null)}
          >
            <div className="bg-blue-600 p-2 rounded-xl text-white shadow-lg shadow-blue-200 group-hover:scale-110 transition-transform">
              <BookOpen size={24} strokeWidth={2.5} />
            </div>
            <div>
              <span className="font-black text-xl tracking-tighter uppercase leading-none block">TSUE Economics</span>
              <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest leading-none">Global Methodological Guide</span>
            </div>
          </div>

          <div className="hidden md:flex items-center gap-8">
            <button onClick={() => setSelectedTopicId(null)} className="text-sm font-black uppercase tracking-widest text-slate-600 hover:text-blue-600 transition-colors">Portal</button>
            <a href="#curriculum" className="text-sm font-black uppercase tracking-widest text-slate-600 hover:text-blue-600 transition-colors">Curriculum</a>
            <button onClick={handlePrint} className="bg-slate-900 text-white px-6 py-2.5 rounded-full text-xs font-black uppercase tracking-widest hover:bg-blue-600 transition-all shadow-xl shadow-slate-100">Export PDF</button>
          </div>

          <button 
            className="md:hidden p-2 text-slate-900"
            onClick={() => setIsMenuOpen(!isMenuOpen)}
          >
            {isMenuOpen ? <X size={28} /> : <Menu size={28} />}
          </button>
        </div>
      </nav>

      {/* Mobile Menu Overlay */}
      <div className={`fixed inset-0 z-[90] bg-white transition-all duration-500 md:hidden flex flex-col items-center justify-center gap-8 no-print ${
        isMenuOpen ? 'opacity-100 translate-y-0' : 'opacity-0 -translate-y-full pointer-events-none'
      }`}>
        <button onClick={() => { setSelectedTopicId(null); setIsMenuOpen(false); }} className="text-2xl font-black uppercase tracking-widest">Home Portal</button>
        <a href="#curriculum" onClick={() => setIsMenuOpen(false)} className="text-2xl font-black uppercase tracking-widest">Curriculum</a>
        <button onClick={() => { handlePrint(); setIsMenuOpen(false); }} className="bg-blue-600 text-white px-8 py-4 rounded-full font-black uppercase tracking-widest">Download Guide</button>
      </div>

      {/* --- Hero Section --- */}
      {!selectedTopicId && (
        <>
          <section className="relative pt-48 pb-32 overflow-hidden px-6">
            <div className="absolute top-0 left-1/2 -translate-x-1/2 w-full max-w-7xl h-full -z-10 opacity-10">
              <div className="absolute top-20 right-0 w-96 h-96 bg-blue-400 rounded-full blur-[120px]" />
              <div className="absolute bottom-0 left-0 w-96 h-96 bg-indigo-400 rounded-full blur-[120px]" />
            </div>

            <div className="max-w-5xl mx-auto text-center space-y-10 animate-in fade-in slide-in-from-bottom-12 duration-1000">
              <div className="inline-flex items-center gap-2 px-4 py-2 bg-slate-50 rounded-full border border-slate-200">
                <Globe size={14} className="text-blue-600" />
                <span className="text-[10px] font-black uppercase tracking-[0.2em] text-slate-500">Academic Year 2024-2025</span>
              </div>
              <h1 className="text-6xl md:text-9xl font-black text-slate-900 tracking-tighter leading-[0.85] uppercase">
                Economics of <br/> 
                <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-600 to-indigo-600">Commercial</span> <br/>
                Enterprises
              </h1>
              <p className="text-xl md:text-2xl text-slate-500 max-w-3xl mx-auto font-medium leading-relaxed">
                Elevating the educational standard for Tashkent State University of Economics. A unified methodological platform for 15 core modules, designed for the next generation of business leaders.
              </p>
              <div className="flex flex-wrap justify-center gap-4 pt-6">
                <a href="#curriculum" className="bg-blue-600 text-white px-10 py-5 rounded-full font-black shadow-2xl shadow-blue-200 hover:scale-105 transition-all flex items-center gap-3">
                  EXPLORE CURRICULUM <ChevronDown size={20} />
                </a>
                <button onClick={handlePrint} className="bg-white text-slate-900 border-2 border-slate-100 px-10 py-5 rounded-full font-black hover:bg-slate-50 transition-all flex items-center gap-3">
                  SYSTEM MANUAL <Download size={20} />
                </button>
              </div>
            </div>
          </section>

          {/* Stats Bar */}
          <section className="border-y border-slate-100 py-12 bg-slate-50/50">
            <div className="max-w-7xl mx-auto px-6 grid grid-cols-2 md:grid-cols-4 gap-12 text-center">
              <div>
                <p className="text-4xl font-black text-slate-900">15</p>
                <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mt-1">Modules</p>
              </div>
              <div>
                <p className="text-4xl font-black text-slate-900">45+</p>
                <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mt-1">Practical Tasks</p>
              </div>
              <div>
                <p className="text-4xl font-black text-slate-900">100%</p>
                <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mt-1">Digital Ready</p>
              </div>
              <div>
                <p className="text-4xl font-black text-slate-900">Ph.D</p>
                <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mt-1">Certified Methodology</p>
              </div>
            </div>
          </section>

          {/* Topics Curriculum Grid */}
          <section id="curriculum" className="max-w-7xl mx-auto px-6 py-32 space-y-16">
            <div className="flex flex-col md:flex-row md:items-end justify-between gap-8 border-b border-slate-100 pb-12">
              <div className="space-y-4">
                <Badge color="blue">Course Catalog</Badge>
                <h3 className="text-4xl md:text-6xl font-black text-slate-900 tracking-tighter uppercase leading-none">
                  Comprehensive <br/> <span className="text-blue-600">Learning Paths</span>
                </h3>
              </div>
              <div className="relative w-full md:w-96 group">
                <Search className="absolute left-5 top-1/2 -translate-y-1/2 text-slate-300 group-focus-within:text-blue-600 transition-colors" size={20} />
                <input 
                  type="text" 
                  placeholder="Search modules..."
                  className="w-full pl-14 pr-6 py-5 bg-slate-50 border border-slate-100 rounded-3xl outline-none focus:ring-4 focus:ring-blue-100 focus:border-blue-300 transition-all font-bold text-slate-700"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                />
              </div>
            </div>

            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
              {filteredTopics.map((topic) => (
                <div 
                  key={topic.id}
                  onClick={() => { setSelectedTopicId(topic.id); window.scrollTo({ top: 0, behavior: 'smooth' }); }}
                  className="group bg-white rounded-[2.5rem] border border-slate-100 p-10 hover:border-blue-600 hover:shadow-3xl transition-all cursor-pointer flex flex-col h-full relative overflow-hidden"
                >
                  <div className="absolute top-0 right-0 p-8 text-8xl font-black text-slate-50 group-hover:text-blue-50 transition-colors leading-none -z-0">
                    {topic.id < 10 ? `0${topic.id}` : topic.id}
                  </div>
                  <div className="relative z-10 flex flex-col h-full space-y-8">
                    <div className="w-16 h-16 bg-slate-50 rounded-2xl flex items-center justify-center text-slate-300 group-hover:bg-blue-600 group-hover:text-white transition-all shadow-sm">
                      <GraduationCap size={32} strokeWidth={2.5} />
                    </div>
                    <div className="space-y-3">
                      <h4 className="text-2xl font-black text-slate-900 group-hover:text-blue-700 transition-colors uppercase leading-none tracking-tighter">
                        {topic.title}
                      </h4>
                      <p className="text-sm text-slate-400 font-bold uppercase tracking-widest">{topic.summary}</p>
                    </div>
                    <div className="pt-6 mt-auto border-t border-slate-50 flex items-center justify-between">
                      <span className="text-[10px] font-black uppercase text-slate-300 group-hover:text-blue-400">View Module Content</span>
                      <ArrowRight size={20} className="text-slate-200 group-hover:text-blue-600 translate-x-0 group-hover:translate-x-2 transition-all" strokeWidth={3} />
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </section>
        </>
      )}

      {/* --- Topic Content Detail View --- */}
      {selectedTopicId && (
        <div className="animate-in fade-in slide-in-from-bottom-10 duration-700">
          {/* Detailed Header for Topic */}
          <section className="bg-slate-900 text-white pt-48 pb-24 px-6 relative overflow-hidden">
            <div className="absolute inset-0 bg-blue-600/10 mix-blend-overlay" />
            <div className="max-w-5xl mx-auto relative z-10 space-y-10">
              <button 
                onClick={() => setSelectedTopicId(null)}
                className="flex items-center gap-3 text-blue-400 font-black uppercase tracking-widest text-xs hover:text-white transition-colors"
              >
                <ArrowRight className="rotate-180" size={16} strokeWidth={3} /> Back to Hub
              </button>
              
              <div className="space-y-6">
                <div className="flex items-center gap-6">
                  <div className="px-5 py-1.5 bg-blue-600 text-white text-sm font-black rounded-full uppercase tracking-widest">Module {currentTopic?.id}</div>
                  <div className="h-px flex-1 bg-white/10" />
                </div>
                <h1 className="text-5xl md:text-8xl font-black uppercase tracking-tighter leading-[0.9]">
                  {currentTopic?.title}
                </h1>
                <p className="text-2xl md:text-3xl text-slate-400 font-medium italic border-l-4 border-blue-600 pl-8 leading-relaxed max-w-4xl">
                  {currentTopic?.summary}
                </p>
              </div>
            </div>
          </section>

          <main className="max-w-5xl mx-auto px-6 py-20 pb-40">
            {/* Section 1: Objectives */}
            <SectionHeader icon={<Target size={24} />} title="Learning Objectives" />
            <div className="grid md:grid-cols-3 gap-6">
              {[
                { label: "Acquired Knowledge", text: currentTopic?.learningObjectives.knowledge, color: "blue" as const, icon: <BookOpen size={20} /> },
                { label: "Applied Skills", text: currentTopic?.learningObjectives.skills, color: "green" as const, icon: <CheckCircle2 size={20} /> },
                { label: "Professional Competencies", text: currentTopic?.learningObjectives.competencies, color: "rose" as const, icon: <TrendingUp size={20} /> },
              ].map((obj, i) => (
                <div key={i} className="p-10 rounded-[2.5rem] border border-slate-100 bg-white shadow-sm hover:shadow-xl transition-shadow relative overflow-hidden group">
                  <div className={`text-slate-800 text-xs font-black uppercase tracking-[0.2em] mb-6 flex items-center gap-3`}>
                    <div className={`p-2 rounded-xl bg-slate-50 text-blue-600 shadow-inner group-hover:scale-110 transition-transform`}>{obj.icon}</div>
                    {obj.label}
                  </div>
                  <p className="text-slate-600 leading-relaxed font-bold text-lg">{obj.text}</p>
                </div>
              ))}
            </div>

            {/* Section 2: Lesson Plan */}
            <SectionHeader icon={<Layers size={24} />} title="Course Roadmap" />
            <div className="space-y-4">
              {currentTopic?.lessonPlan.map((step, i) => (
                <div key={i} className="flex items-center gap-10 bg-white p-10 rounded-3xl border border-slate-100 shadow-sm transition-all hover:bg-slate-50 group">
                  <span className="text-blue-100 group-hover:text-blue-600 font-black text-6xl transition-colors italic w-20 leading-none">0{i+1}</span>
                  <span className="text-slate-800 font-black text-2xl uppercase tracking-tighter">{step}</span>
                </div>
              ))}
            </div>

            {/* Section 3: Theory */}
            <SectionHeader icon={<Info size={24} />} title="Theoretical Content" />
            <div className="space-y-12">
              {currentTopic?.theoreticalContent.map((theory, i) => (
                <div key={i} className="bg-white p-16 rounded-[4rem] border border-slate-100 shadow-sm group">
                  <div className="flex flex-col md:flex-row gap-12">
                    <div className="md:w-1/3">
                      <h4 className="text-blue-600 font-black text-3xl uppercase leading-none tracking-tighter">
                        Section <br/> {theory.section.split('.')[0]}
                      </h4>
                      <p className="text-slate-400 font-bold uppercase tracking-widest text-[10px] mt-4">{theory.section}</p>
                    </div>
                    <div className="md:w-2/3">
                      <p className="text-slate-600 leading-[1.8] text-xl text-justify font-medium">{theory.content}</p>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            {/* Section 4: Practical Tasks */}
            <SectionHeader icon={<Briefcase size={24} />} title="Practical Applications" />
            <div className="grid md:grid-cols-2 gap-8">
              {currentTopic?.practicalTasks.map((task) => (
                <div key={task.id} className="bg-slate-50 rounded-[3.5rem] p-12 border border-slate-200/50 flex flex-col h-full">
                  <div className="flex justify-between items-center mb-10">
                    <Badge color="blue">Workshop Assignment</Badge>
                    <span className="text-[10px] font-black text-slate-300">#{task.id}</span>
                  </div>
                  <h4 className="text-3xl font-black text-slate-900 mb-6 uppercase tracking-tighter leading-none">{task.title}</h4>
                  <div className="space-y-10 flex-1">
                    <p className="text-xl text-slate-600 font-black italic leading-tight">"{task.objective}"</p>
                    <div className="space-y-4">
                      {task.instructions.map((ins, i) => (
                        <div key={i} className="flex gap-4 text-slate-600 font-bold text-lg">
                          <span className="w-8 h-8 rounded-xl bg-white shadow-sm text-blue-600 flex items-center justify-center text-xs font-black shrink-0">{i+1}</span>
                          {ins}
                        </div>
                      ))}
                    </div>
                  </div>
                  <div className="mt-12 pt-8 border-t border-slate-200 flex items-center justify-between">
                    <span className="text-[10px] font-black uppercase text-slate-400">Deliverable Format:</span>
                    <Badge color="green" className="py-2 px-6">{task.deliverable}</Badge>
                  </div>
                </div>
              ))}
            </div>

            {/* Section 5: Case Study */}
            <SectionHeader icon={<Users size={24} />} title="Business Case Analysis" />
            <div className="space-y-12">
              {currentTopic?.caseStudies.map((cs) => (
                <div key={cs.id} className="bg-slate-900 rounded-[5rem] overflow-hidden shadow-2xl">
                  <div className="grid lg:grid-cols-12">
                    <div className="lg:col-span-5 p-16 text-white bg-gradient-to-br from-slate-900 to-indigo-900">
                      <Badge color="blue" className="bg-white/10 text-white border-white/20 mb-8 w-fit">Decision Case</Badge>
                      <h4 className="text-5xl font-black uppercase tracking-tighter leading-none mb-6">{cs.title}</h4>
                      <p className="text-slate-400 font-bold italic text-lg leading-relaxed">Collaborative strategy session requiring real-time market data evaluation.</p>
                    </div>
                    <div className="lg:col-span-7 p-16 bg-white space-y-12">
                      <div className="space-y-4">
                        <span className="text-[10px] font-black uppercase tracking-[0.3em] text-blue-600">The Context</span>
                        <p className="text-slate-800 text-2xl font-black leading-snug italic">"{cs.situation}"</p>
                      </div>
                      <div className="space-y-6">
                        <span className="text-[10px] font-black uppercase tracking-[0.3em] text-blue-600">Inquiry Tasks</span>
                        <div className="grid gap-3">
                          {cs.questions.map((q, i) => (
                            <div key={i} className="p-6 bg-slate-50 rounded-2xl flex items-center gap-6 border border-slate-100 hover:bg-slate-900 hover:text-white transition-all group cursor-default">
                              <div className="w-10 h-10 rounded-xl bg-white text-slate-900 flex items-center justify-center font-black group-hover:scale-90 transition-transform shrink-0">0{i+1}</div>
                              <p className="font-black text-lg uppercase tracking-tight">{q}</p>
                            </div>
                          ))}
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            {/* Section 6: Problem Situations */}
            <SectionHeader icon={<AlertTriangle size={24} />} title="Risk & Crisis Scenarios" />
            <div className="space-y-8">
              {currentTopic?.problemSituations.map((ps) => (
                <div key={ps.id} className="bg-rose-50 p-16 rounded-[4rem] border border-rose-100 space-y-12 relative overflow-hidden shadow-sm">
                  <AlertTriangle className="absolute -top-20 -right-20 text-rose-500 opacity-5" size={320} />
                  <div className="relative z-10 grid lg:grid-cols-2 gap-20">
                    <div className="space-y-6">
                      <Badge color="rose">Problem ID: {ps.id}</Badge>
                      <h5 className="text-[10px] font-black text-rose-400 uppercase tracking-widest">Complex Reality:</h5>
                      <p className="text-slate-800 text-3xl font-black italic leading-tight">"{ps.situation}"</p>
                    </div>
                    <div className="space-y-6">
                      <h5 className="text-[10px] font-black text-rose-500 uppercase tracking-widest">Critical Conflict:</h5>
                      <p className="text-rose-900 text-4xl font-black uppercase tracking-tighter leading-none">{ps.problem}</p>
                      <div className="pt-10 space-y-4">
                        {ps.questions.map((q, i) => (
                          <div key={i} className="bg-white p-6 rounded-3xl border border-rose-100 text-lg font-black text-rose-800 text-center uppercase tracking-tight shadow-sm hover:scale-105 transition-transform">
                            {q}
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            {/* Section 7: Discussion */}
            <div className="grid lg:grid-cols-2 gap-12 mt-20">
              <div className="space-y-8">
                <SectionHeader icon={<HelpCircle size={24} />} title="Critical Debate" />
                <div className="bg-white p-12 rounded-[3.5rem] border border-slate-100 shadow-sm space-y-6">
                  {currentTopic?.discussionQuestions.map((q, i) => (
                    <div key={i} className="flex gap-6 p-6 rounded-3xl bg-slate-50/50 border border-transparent hover:border-blue-100 hover:bg-white hover:shadow-xl transition-all group">
                      <div className="mt-1.5 w-3 h-3 rounded-full bg-blue-600 shrink-0 shadow-lg shadow-blue-200 group-hover:scale-150 transition-transform" />
                      <p className="text-xl font-black text-slate-800 leading-tight uppercase tracking-tight">{q}</p>
                    </div>
                  ))}
                </div>
              </div>
              <div className="space-y-8">
                <SectionHeader icon={<Award size={24} />} title="Self-Directed Study" />
                <div className="grid gap-4">
                  {currentTopic?.independentWork.map((topic, i) => (
                    <div key={i} className="bg-slate-900 p-8 rounded-[3rem] text-white flex items-center gap-8 group hover:bg-blue-600 transition-all cursor-default">
                      <div className="p-4 bg-white/10 rounded-2xl group-hover:bg-white group-hover:text-blue-600 transition-all"><BookOpen size={28} strokeWidth={2.5} /></div>
                      <div>
                        <span className="text-[10px] font-black uppercase text-slate-500 group-hover:text-blue-100 tracking-widest">Research Module</span>
                        <h5 className="text-xl font-black uppercase tracking-tighter leading-none mt-1">{topic}</h5>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </main>
        </div>
      )}

      {/* --- Footer Section --- */}
      <footer className="bg-slate-50 py-32 border-t border-slate-200 no-print">
        <div className="max-w-7xl mx-auto px-6 grid md:grid-cols-12 gap-16">
          <div className="md:col-span-5 space-y-8">
            <div className="flex items-center gap-4">
              <div className="w-16 h-16 bg-slate-900 text-white rounded-2xl flex items-center justify-center font-black text-xl shadow-2xl">TSUE</div>
              <div>
                <h6 className="text-xl font-black uppercase tracking-tighter">Academic Portal</h6>
                <p className="text-xs text-slate-400 font-bold uppercase tracking-widest mt-1">Global Economic Excellence</p>
              </div>
            </div>
            <p className="text-slate-500 font-medium leading-relaxed max-w-sm">
              The Tashkent State University of Economics continues to lead in methodological innovation, providing world-class resources for modern business education in Uzbekistan and beyond.
            </p>
          </div>
          
          <div className="md:col-span-2 space-y-6">
            <h6 className="text-[10px] font-black uppercase tracking-[0.3em] text-slate-400">Navigation</h6>
            <div className="flex flex-col gap-4 text-sm font-bold uppercase tracking-widest text-slate-600">
              <button onClick={() => setSelectedTopicId(null)} className="hover:text-blue-600 text-left">Home Portal</button>
              <a href="#curriculum" className="hover:text-blue-600">Curriculum</a>
              <button onClick={handlePrint} className="hover:text-blue-600 text-left">Manual Export</button>
            </div>
          </div>

          <div className="md:col-span-5 text-right flex flex-col items-end gap-6">
            <div className="space-y-2">
              <p className="text-[10px] font-black text-slate-300 uppercase tracking-[0.5em]">Authored & Compiled by</p>
              <p className="text-3xl font-black text-slate-900 uppercase tracking-tighter">PhD. Farrukh Suleimanov</p>
              <p className="text-sm text-blue-600 font-black uppercase tracking-widest italic">Chair of Commercial Enterprise Economics</p>
            </div>
            <div className="pt-10 flex items-center gap-6">
               <div className="px-5 py-2 rounded-full border border-slate-200 text-[10px] font-black uppercase text-slate-400">Copyright © 2025 TSUE</div>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default App;
